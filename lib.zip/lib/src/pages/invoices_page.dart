// lib/src/pages/invoices_page.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import '../data/models/invoice.dart';
import '../data/repositories/invoice_repository.dart';
import '../widgets/form_helpers.dart';

class InvoicesPage extends StatefulWidget {
  const InvoicesPage({super.key});

  @override
  State<InvoicesPage> createState() => _InvoicesPageState();
}

class _InvoicesPageState extends State<InvoicesPage> {
  final _repo = InvoiceRepository();
  String _filter = 'Client'; // Client | Vendor

  @override
  Widget build(BuildContext context) {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) {
      return const Scaffold(
        body: Center(child: Text('Please sign in to view invoices')),
      );
    }

    final currency = NumberFormat.simpleCurrency();

    return Scaffold(
      appBar: AppBar(title: const Text('Invoices')),
      body: Column(
        children: [
          // --- Filter control (Client / Vendor) ---
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'Client', label: Text('Client')),
                  ButtonSegment(value: 'Vendor', label: Text('Vendor')),
                ],
                selected: {_filter},
                onSelectionChanged: (s) {
                  if (s.isNotEmpty) setState(() => _filter = s.first);
                },
                showSelectedIcon: false,
              ),
            ),
          ),
          const SizedBox(height: 4),

          // --- Invoices list ---
          Expanded(
            child: StreamBuilder<List<Invoice>>(
              stream: _repo.streamAllForUser(me.uid),
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                var items = snap.data ?? const <Invoice>[];

                // Apply filter (no "All" option by design)
                items = items.where((i) => i.invoiceType == _filter).toList();

                // Sort: invoiceDate desc, fallback to createdAt desc, then invoiceNumber desc
                items.sort((a, b) {
                  final ad = a.invoiceDate ?? a.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
                  final bd = b.invoiceDate ?? b.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
                  final byDate = bd.compareTo(ad); // newest first
                  if (byDate != 0) return byDate;
                  return (b.invoiceNumber).compareTo(a.invoiceNumber);
                });

                if (items.isEmpty) {
                  return const _Empty();
                }

                return ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final inv = items[i];
                    final title = inv.invoiceNumber.isNotEmpty
                        ? 'Invoice ${inv.invoiceNumber}'
                        : 'Invoice ${inv.id.substring(0, 6)}';

                    return Card(
                      margin: EdgeInsets.zero,
                      child: ListTile(
                        dense: true,
                        visualDensity: const VisualDensity(vertical: -2),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        // Subtitle beneath title: Original Amount
                        subtitle: Text(
                          'Original Amount: ${currency.format(inv.invoiceAmount)}',
                        ),
                        // Right-aligned: Balance = amount - paid
                        trailing: Text(
                          'Balance: ${currency.format(inv.balance)}',
                          textAlign: TextAlign.right,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        onTap: () => _openInvoice(context, inv),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.receipt_long, size: 80),
            SizedBox(height: 12),
            Text('No invoices yet'),
          ],
        ),
      ),
    );
  }
}

Future<void> _openInvoice(BuildContext context, Invoice inv) async {
  // Determine if current user owns the related project
  final uid = FirebaseAuth.instance.currentUser?.uid;
  bool canEdit = false;
  try {
    final p = await FirebaseFirestore.instance
        .collection('projects')
        .doc(inv.projectId)
        .get();
    final ownerUid = p.data()?['ownerUid'] as String?;
    canEdit = (uid != null && ownerUid == uid);
  } catch (_) {
    canEdit = false;
  }

  await _showEditInvoiceDialog(context, inv, canEdit: canEdit);
}

Future<void> _showEditInvoiceDialog(BuildContext context, Invoice inv, {required bool canEdit}) async {
  final invoiceNumberCtl = TextEditingController(text: inv.invoiceNumber);
  final projectNumberCtl = TextEditingController(text: inv.projectNumber?.toString() ?? '');
  final invoiceAmountCtl = TextEditingController(text: inv.invoiceAmount.toStringAsFixed(2));
  final amountPaidCtl = TextEditingController(text: inv.amountPaid.toStringAsFixed(2));
  final documentLinkCtl = TextEditingController(text: inv.documentLink ?? '');

  String invoiceType = inv.invoiceType;
  DateTime? invoiceDate = inv.invoiceDate;
  DateTime? dueDate = inv.dueDate;
  DateTime? paidDate = inv.paidDate;

  final formKey = GlobalKey<FormState>();
  final repo = InvoiceRepository();

  Future<void> pickDate(String which) async {
    final seed = (which == 'invoice')
        ? (invoiceDate ?? DateTime.now())
        : (which == 'due')
        ? (dueDate ?? DateTime.now())
        : (paidDate ?? DateTime.now());
    final d = await showDatePicker(
      context: context,
      initialDate: seed,
      firstDate: DateTime(seed.year - 5),
      lastDate: DateTime(seed.year + 5),
    );
    if (d != null) {
      switch (which) {
        case 'invoice':
          invoiceDate = d;
          break;
        case 'due':
          dueDate = d;
          break;
        case 'paid':
          paidDate = d;
          break;
      }
    }
  }

  void _viewOnlyTap() {
    if (!canEdit) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('View-only: only the project owner can modify invoices.')),
      );
    }
  }

  await showDialog<void>(
    context: context,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text('Invoice ${inv.invoiceNumber.isNotEmpty ? inv.invoiceNumber : inv.id.substring(0, 6)}'),
            content: Form(
              key: formKey,
              child: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      appTextField('Invoice Number', invoiceNumberCtl, required: true),
                      const SizedBox(height: 10),
                      appTextField('Project Number', projectNumberCtl, hint: 'numbers only'),
                      const SizedBox(height: 10),
                      appTextField('Invoice Amount', invoiceAmountCtl, required: true, keyboardType: TextInputType.number),
                      const SizedBox(height: 10),
                      appTextField('Amount Paid', amountPaidCtl, keyboardType: TextInputType.number),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: appDateField(
                              label: 'Invoice Date',
                              value: invoiceDate,
                              onPick: () async {
                                if (!canEdit) return _viewOnlyTap();
                                await pickDate('invoice');
                                setState(() {});
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: appDateField(
                              label: 'Due Date',
                              value: dueDate,
                              onPick: () async {
                                if (!canEdit) return _viewOnlyTap();
                                await pickDate('due');
                                setState(() {});
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      appDateField(
                        label: 'Paid Date',
                        value: paidDate,
                        onPick: () async {
                          if (!canEdit) return _viewOnlyTap();
                          await pickDate('paid');
                          setState(() {});
                        },
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: invoiceType,
                        items: const [
                          DropdownMenuItem(value: 'Client', child: Text('Client')),
                          DropdownMenuItem(value: 'Vendor', child: Text('Vendor')),
                        ],
                        onChanged: canEdit ? (v) => setState(() => invoiceType = v ?? invoiceType) : (v) => _viewOnlyTap(),
                        decoration: const InputDecoration(
                          labelText: 'Invoice Type',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 10),
                      appTextField('Document Link', documentLinkCtl),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              if (canEdit)
                TextButton(
                  onPressed: () async {
                    final ok = await confirmDialog(context, 'Delete this invoice?');
                    if (!ok) return;
                    try {
                      await repo.delete(inv.id);
                      // ignore: use_build_context_synchronously
                      Navigator.pop(context);
                    } catch (e) {
                      // ignore: use_build_context_synchronously
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to delete: $e')));
                    }
                  },
                  child: const Text('Delete'),
                ),
              TextButton(onPressed: () => Navigator.pop(context), child: Text(canEdit ? 'Cancel' : 'Close')),
              if (canEdit)
                FilledButton(
                  onPressed: () async {
                    if (!(formKey.currentState?.validate() ?? false)) return;

                    final amt = double.tryParse(invoiceAmountCtl.text.trim()) ?? inv.invoiceAmount;
                    final paid = amountPaidCtl.text.trim().isEmpty
                        ? inv.amountPaid
                        : (double.tryParse(amountPaidCtl.text.trim()) ?? inv.amountPaid);

                    int? projNum;
                    final pn = projectNumberCtl.text.trim();
                    if (pn.isNotEmpty) projNum = int.tryParse(pn);

                    try {
                      await repo.update(inv.id, {
                        'invoiceNumber': invoiceNumberCtl.text.trim(),
                        'projectNumber': projNum,
                        'invoiceAmount': amt,
                        'amountPaid': paid, // canonical
                        'invoiceDate': invoiceDate != null ? Timestamp.fromDate(invoiceDate!) : null,
                        'dueDate': dueDate != null ? Timestamp.fromDate(dueDate!) : null,
                        'paidDate': paidDate != null ? Timestamp.fromDate(paidDate!) : null,
                        'documentLink': documentLinkCtl.text.trim().isNotEmpty ? documentLinkCtl.text.trim() : null,
                        'invoiceType': invoiceType,
                      });
                      // ignore: use_build_context_synchronously
                      Navigator.pop(context);
                    } catch (e) {
                      // ignore: use_build_context_synchronously
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to save: $e')));
                    }
                  },
                  child: const Text('Save'),
                ),
            ],
          );
        },
      );
    },
  );
}
