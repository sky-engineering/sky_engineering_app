// lib/src/widgets/tasks_by_subphase_section.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../data/models/project.dart';
import '../data/models/task.dart';
import '../data/repositories/task_repository.dart';
import '../data/repositories/project_repository.dart';
import '../data/repositories/subphase_template_repository.dart';
import 'form_helpers.dart';
import '../ui/loading_overlay.dart';

const _kTaskStatuses = <String>['In Progress', 'On Hold', 'Pending', 'Completed'];
const _kSubphaseStatuses = <String>['In Progress', 'On Hold', 'Completed'];

class TasksBySubphaseSection extends StatelessWidget {
  final String projectId;
  final bool isOwner;
  final List<SelectedSubphase>? selectedSubphases;

  const TasksBySubphaseSection({
    super.key,
    required this.projectId,
    required this.isOwner,
    required this.selectedSubphases,
  });

  @override
  Widget build(BuildContext context) {
    final repo = TaskRepository();
    final sel = (selectedSubphases ?? <SelectedSubphase>[])
        .where((s) => _isValidCode(s.code))
        .toList()
      ..sort((a, b) => a.code.compareTo(b.code));

    final statusByCode = {for (final s in sel) s.code: s.status};

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: StreamBuilder<List<TaskItem>>(
          stream: repo.streamByProject(projectId),
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Padding(
                padding: EdgeInsets.all(12),
                child: CircularProgressIndicator(),
              );
            }
            final tasks = (snap.data ?? const <TaskItem>[]);

            // Partition tasks: map<code, list> for selected codes; everything else -> other
            final codeSet = sel.map((e) => e.code).toSet();
            final Map<String, List<TaskItem>> byCode = {
              for (final s in sel) s.code: <TaskItem>[],
            };
            final List<TaskItem> other = [];

            for (final t in tasks) {
              final code = _sanitizeCode(t.taskCode);
              if (code != null && codeSet.contains(code)) {
                byCode[code]!.add(t);
              } else {
                other.add(t);
              }
            }

            // Sort each box (dueDate asc, then title)
            int _cmp(TaskItem a, TaskItem b) {
              final ad = a.dueDate, bd = b.dueDate;
              if (ad != null && bd != null) {
                final c = ad.compareTo(bd);
                if (c != 0) return c;
              } else if (ad == null && bd != null) {
                return 1;
              } else if (ad != null && bd == null) {
                return -1;
              }
              return a.title.toLowerCase().compareTo(b.title.toLowerCase());
            }
            for (final list in byCode.values) list.sort(_cmp);
            other.sort(_cmp);

            final boxes = <Widget>[
              Text('Tasks', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),

              if (sel.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    'No subphases selected for this project yet.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),

              ...sel.map((s) => _SubphaseBox(
                projectId: projectId,
                label: '${s.code}  ${s.name}',
                tasks: byCode[s.code] ?? const <TaskItem>[],
                isOwner: isOwner,
                subphaseCode: s.code,
                currentStatus: statusByCode[s.code] ?? 'In Progress',
                onChangeStatus: (newStatus) async {
                  if (!isOwner) return _SubphaseBox._viewOnlySnack(context);
                  await _updateSubphaseStatus(
                    context,
                    projectId: projectId,
                    selected: selectedSubphases ?? const <SelectedSubphase>[],
                    code: s.code,
                    newStatus: newStatus,
                  );
                },
              )),

              _SubphaseBox(
                projectId: projectId,
                label: 'Other',
                tasks: other,
                isOwner: isOwner,
                subphaseCode: null,
                currentStatus: null,
                onChangeStatus: null,
              ),

              const SizedBox(height: 8),

              if (isOwner)
                Align(
                  alignment: Alignment.centerLeft,
                  child: FilledButton.icon(
                    onPressed: () => _showAddTaskDialog(context, projectId),
                    icon: const Icon(Icons.add),
                    label: const Text('New Task'),
                  ),
                ),
            ];

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ...boxes.expand((w) sync* {
                  yield w;
                  if (w is _SubphaseBox) yield const SizedBox(height: 10);
                }),
              ],
            );
          },
        ),
      ),
    );
  }

  static bool _isValidCode(String? code) =>
      code != null && code.trim().length == 4 && int.tryParse(code) != null;

  static String? _sanitizeCode(String? code) {
    if (!_isValidCode(code)) return null;
    return code!.trim();
  }
}

class _SubphaseBox extends StatelessWidget {
  final String projectId;
  final String label; // "0201  Concept Site Plan" or "Other"
  final List<TaskItem> tasks;
  final bool isOwner;

  final String? subphaseCode;      // null for Other
  final String? currentStatus;     // null for Other
  final ValueChanged<String>? onChangeStatus;

  const _SubphaseBox({
    required this.projectId,
    required this.label,
    required this.tasks,
    required this.isOwner,
    required this.subphaseCode,
    required this.currentStatus,
    required this.onChangeStatus,
  });

  @override
  Widget build(BuildContext context) {
    final outline = Theme.of(context).colorScheme.outlineVariant.withOpacity(0.4);
    final headerStyle = const TextStyle(fontWeight: FontWeight.w600, fontSize: 15);
    final statusStyle = Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 12);

    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: outline),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header line
          Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: headerStyle,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (subphaseCode != null)
                DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _kSubphaseStatuses.contains(currentStatus)
                        ? currentStatus
                        : 'In Progress',
                    items: _kSubphaseStatuses
                        .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                        .toList(),
                    onChanged: isOwner ? (v) { if (v != null) onChangeStatus?.call(v); } : null,
                    isDense: true,
                    icon: const SizedBox.shrink(), // hide arrow
                    style: statusStyle,
                  ),
                ),
            ],
          ),

          // Owner-only helper row (insert defaults)
          if (isOwner && subphaseCode != null) ...[
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                style: TextButton.styleFrom(visualDensity: const VisualDensity(vertical: -2)),
                onPressed: () => _insertDefaultsForSubphase(context, projectId, subphaseCode!),
                child: const Text('Insert defaults'),
              ),
            ),
          ],

          const SizedBox(height: 2),

          if (tasks.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Text('No tasks', style: Theme.of(context).textTheme.bodySmall),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: tasks.length,
              separatorBuilder: (_, __) => const SizedBox(height: 4),
              itemBuilder: (context, i) {
                final t = tasks[i];
                return _CompactTaskTile(
                  task: t,
                  isOwner: isOwner,
                  onToggleStar: () async {
                    if (!isOwner) return _viewOnlySnack(context);
                    await TaskRepository().update(t.id, {'isStarred': !t.isStarred});
                  },
                  onChangeStatus: (newStatus) async {
                    if (!isOwner) return _viewOnlySnack(context);
                    await TaskRepository().update(t.id, {
                      'taskStatus': newStatus,
                      'status': _legacyFromNew(newStatus), // mirror
                    });
                  },
                  onTap: () => _showEditTaskDialog(context, t, canEdit: isOwner),
                );
              },
            ),
        ]),
      ),
    );
  }

  static void _viewOnlySnack(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('View-only: only the project owner can modify tasks.')),
    );
  }

  static String _legacyFromNew(String taskStatus) {
    switch (taskStatus) {
      case 'In Progress': return 'In Progress';
      case 'On Hold':     return 'Blocked';
      case 'Completed':   return 'Done';
      case 'Pending':
      default:            return 'Open';
    }
  }
}

// ===== Compact task tile =====
class _CompactTaskTile extends StatelessWidget {
  final TaskItem task;
  final bool isOwner;
  final VoidCallback onToggleStar;
  final ValueChanged<String> onChangeStatus;
  final VoidCallback onTap;

  const _CompactTaskTile({
    required this.task,
    required this.isOwner,
    required this.onToggleStar,
    required this.onChangeStatus,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final small = Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 12);
    final hasDesc = (task.description ?? '').trim().isNotEmpty;

    final filledStarColor = Theme.of(context).colorScheme.secondary;
    final hollowStarColor = Theme.of(context).colorScheme.onSurfaceVariant;

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
        child: Row(
          crossAxisAlignment:
          hasDesc ? CrossAxisAlignment.start : CrossAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.only(top: hasDesc ? 2 : 0),
              child: IconButton(
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                iconSize: 18,
                splashRadius: 16,
                onPressed: onToggleStar,
                icon: Icon(
                  task.isStarred ? Icons.star : Icons.star_border,
                  color: task.isStarred ? filledStarColor : hollowStarColor,
                ),
                tooltip: task.isStarred ? 'Unstar' : 'Star',
              ),
            ),
            const SizedBox(width: 4),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Text(
                          task.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                        ),
                      ),
                      const SizedBox(width: 8),
                      DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: _kTaskStatuses.contains(task.taskStatus)
                              ? task.taskStatus
                              : 'Pending',
                          items: _kTaskStatuses
                              .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                              .toList(),
                          onChanged: isOwner ? (v) => v != null ? onChangeStatus(v) : null : null,
                          isDense: true,
                          icon: const SizedBox.shrink(), // hide arrow
                          style: small, // slightly smaller to match compact text
                        ),
                      ),
                    ],
                  ),
                  if (hasDesc)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(
                        task.description!.trim(),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: small,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------- Add/Edit task dialogs (unchanged) -------------------

Future<void> _showAddTaskDialog(BuildContext context, String projectId) async {
  final titleCtl = TextEditingController();
  final descCtl = TextEditingController();
  final assigneeCtl = TextEditingController();
  final codeCtl = TextEditingController();
  DateTime? dueDate;
  String taskStatus = 'Pending';
  bool isStarred = false;

  final me = FirebaseAuth.instance.currentUser;
  final repo = TaskRepository();
  final formKey = GlobalKey<FormState>();

  if (me == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('You must be signed in.')),
    );
    return;
  }

  String? _validateCode(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return null; // optional
    if (s.length != 4 || int.tryParse(s) == null) return 'Enter a 4-digit code';
    return null;
  }

  Future<void> pickDue() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 5),
    );
    if (d != null) dueDate = d;
  }

  await showDialog<void>(
    context: context,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('New Task'),
            content: Form(
              key: formKey,
              child: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    appTextField('Title', titleCtl, required: true, hint: 'e.g., Site visit'),
                    const SizedBox(height: 10),
                    appTextField('Description', descCtl),
                    const SizedBox(height: 10),

                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: codeCtl,
                            decoration: const InputDecoration(
                              labelText: 'Task Code (optional)',
                              hintText: 'e.g., 0201',
                              border: OutlineInputBorder(),
                            ),
                            keyboardType: TextInputType.number,
                            validator: _validateCode,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: taskStatus,
                            items: _kTaskStatuses
                                .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                                .toList(),
                            onChanged: (v) => setState(() => taskStatus = v ?? 'Pending'),
                            decoration: const InputDecoration(
                              labelText: 'Task Status',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    Row(
                      children: [
                        Expanded(
                          child: appDateField(
                            label: 'Due Date',
                            value: dueDate,
                            onPick: () async {
                              await pickDue();
                              setState(() {});
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: assigneeCtl,
                            decoration: const InputDecoration(
                              labelText: 'Assignee (optional)',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 10),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Star this task'),
                      value: isStarred,
                      onChanged: (v) => setState(() => isStarred = v),
                    ),
                  ]),
                ),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
              FilledButton(
                onPressed: () async {
                  if (!(formKey.currentState?.validate() ?? false)) return;

                  final code = codeCtl.text.trim();
                  final t = TaskItem(
                    id: '_',
                    projectId: projectId,
                    ownerUid: me.uid,
                    title: titleCtl.text.trim(),
                    description: descCtl.text.trim().isEmpty ? null : descCtl.text.trim(),
                    taskStatus: taskStatus,
                    isStarred: isStarred,
                    taskCode: code.isEmpty ? null : code,
                    dueDate: dueDate,
                    assigneeName:
                    assigneeCtl.text.trim().isEmpty ? null : assigneeCtl.text.trim(),
                    createdAt: null,
                    updatedAt: null,
                  );
                  await repo.add(t);
                  // ignore: use_build_context_synchronously
                  Navigator.pop(context);
                },
                child: const Text('Create'),
              ),
            ],
          );
        },
      );
    },
  );
}

Future<void> _showEditTaskDialog(BuildContext context, TaskItem t,
    {required bool canEdit}) async {
  final titleCtl = TextEditingController(text: t.title);
  final descCtl = TextEditingController(text: t.description ?? '');
  final assigneeCtl = TextEditingController(text: t.assigneeName ?? '');
  final codeCtl = TextEditingController(text: t.taskCode ?? '');
  DateTime? dueDate = t.dueDate;
  String taskStatus = t.taskStatus;
  bool isStarred = t.isStarred;

  final repo = TaskRepository();
  final formKey = GlobalKey<FormState>();

  String? _validateCode(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return null; // optional
    if (s.length != 4 || int.tryParse(s) == null) return 'Enter a 4-digit code';
    return null;
  }

  Future<void> pickDue() async {
    final seed = dueDate ?? DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: seed,
      firstDate: DateTime(seed.year - 5),
      lastDate: DateTime(seed.year + 5),
    );
    if (d != null) dueDate = d;
  }

  void _viewOnlyTap() {
    if (!canEdit) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('View-only: only the project owner can modify tasks.')),
      );
    }
  }

  await showDialog<void>(
    context: context,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text('Task: ${t.title}'),
            content: Form(
              key: formKey,
              child: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    appTextField('Title', titleCtl, required: true),
                    const SizedBox(height: 10),
                    appTextField('Description', descCtl),
                    const SizedBox(height: 10),

                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: codeCtl,
                            decoration: const InputDecoration(
                              labelText: 'Task Code (optional)',
                              hintText: 'e.g., 0201',
                              border: OutlineInputBorder(),
                            ),
                            keyboardType: TextInputType.number,
                            validator: _validateCode,
                            readOnly: !canEdit,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _kTaskStatuses.contains(taskStatus) ? taskStatus : 'Pending',
                            items: _kTaskStatuses
                                .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                                .toList(),
                            onChanged: canEdit
                                ? (v) => setState(() => taskStatus = v ?? taskStatus)
                                : (v) => _viewOnlyTap(),
                            decoration: const InputDecoration(
                              labelText: 'Task Status',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    Row(
                      children: [
                        Expanded(
                          child: appDateField(
                            label: 'Due Date',
                            value: dueDate,
                            onPick: () async {
                              if (!canEdit) return _viewOnlyTap();
                              await pickDue();
                              setState(() {});
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: assigneeCtl,
                            decoration: const InputDecoration(
                              labelText: 'Assignee (optional)',
                              border: OutlineInputBorder(),
                            ),
                            readOnly: !canEdit,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Star this task'),
                      value: isStarred,
                      onChanged: canEdit ? (v) => setState(() => isStarred = v) : null,
                    ),
                  ]),
                ),
              ),
            ),
            actions: [
              if (canEdit)
                TextButton(
                  onPressed: () async {
                    final ok = await confirmDialog(context, 'Delete this task?');
                    if (!ok) return;
                    await repo.delete(t.id);
                    // ignore: use_build_context_synchronously
                    Navigator.pop(context);
                  },
                  child: const Text('Delete'),
                ),
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(canEdit ? 'Cancel' : 'Close')),
              if (canEdit)
                FilledButton(
                  onPressed: () async {
                    if (!(formKey.currentState?.validate() ?? false)) return;

                    final code = codeCtl.text.trim();
                    await repo.update(t.id, {
                      'title': titleCtl.text.trim(),
                      'description': descCtl.text.trim().isEmpty ? null : descCtl.text.trim(),
                      'taskStatus': taskStatus,
                      'status': _SubphaseBox._legacyFromNew(taskStatus), // mirror
                      'isStarred': isStarred,
                      'taskCode': code.isEmpty ? null : code,
                      'dueDate': dueDate != null ? Timestamp.fromDate(dueDate!) : null,
                      'assigneeName':
                      assigneeCtl.text.trim().isEmpty ? null : assigneeCtl.text.trim(),
                    });
                    // ignore: use_build_context_synchronously
                    Navigator.pop(context);
                  },
                  child: const Text('Save'),
                ),
            ],
          );
        },
      );
    },
  );
}

/// Insert default tasks for a given subphase code into the current project.
/// Owner-only gate happens at the button level; we also require sign-in here.
/// This version **de-duplicates by title** (case-insensitive) among tasks that already
/// exist for the same `projectId` + `taskCode`.
Future<void> _insertDefaultsForSubphase(
    BuildContext context,
    String projectId,
    String subphaseCode,
    ) async {
  final me = FirebaseAuth.instance.currentUser;
  if (me == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('You must be signed in.')),
    );
    return;
  }

  final templatesRepo = SubphaseTemplateRepository();
  final tasksRepo = TaskRepository();

  try {
    LoadingOverlay.show(context, message: 'Inserting defaults…');

    // Fetch the template for this owner + code
    final tpl = await templatesRepo.getByOwnerAndCode(me.uid, subphaseCode);
    if (tpl == null || tpl.defaultTasks.isEmpty) {
      LoadingOverlay.hide(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No default tasks defined for this subphase.')),
      );
      return;
    }

    // Fetch existing tasks for this project + code (one-shot)
    final existingQs = await FirebaseFirestore.instance
        .collection('tasks')
        .where('projectId', isEqualTo: projectId)
        .where('taskCode', isEqualTo: subphaseCode)
        .get();

    final existingTitleSet = existingQs.docs
        .map((d) => ((d.data()['title'] as String?) ?? '').trim().toLowerCase())
        .where((s) => s.isNotEmpty)
        .toSet();

    // Clean + compute unique list to insert
    final cleanedDefaults = tpl.defaultTasks
        .map((t) => t.trim())
        .where((t) => t.isNotEmpty)
        .toList();

    final toInsert = cleanedDefaults
        .where((t) => !existingTitleSet.contains(t.toLowerCase()))
        .toList();

    LoadingOverlay.hide(context);

    if (toInsert.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('All default tasks are already present.')),
      );
      return;
    }

    final dupes = cleanedDefaults.length - toInsert.length;
    final confirmMsg = (dupes > 0)
        ? 'Insert ${toInsert.length} default task(s) (skipping $dupes duplicate(s)) into $subphaseCode?'
        : 'Insert ${toInsert.length} default task(s) into $subphaseCode?';

    final ok = await confirmDialog(context, confirmMsg);
    if (!ok) return;

    LoadingOverlay.show(context, message: 'Adding tasks…');

    for (final title in toInsert) {
      final t = TaskItem(
        id: '_',
        projectId: projectId,
        ownerUid: me.uid,
        title: title,
        description: null,
        taskStatus: 'Pending',
        isStarred: false,
        taskCode: subphaseCode,
        dueDate: null,
        assigneeName: null,
        createdAt: null,
        updatedAt: null,
      );
      await tasksRepo.add(t);
    }

    LoadingOverlay.hide(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Inserted ${toInsert.length} task(s).')),
    );
  } catch (e) {
    LoadingOverlay.hide(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Failed to insert defaults: $e')),
    );
  }
}

Future<void> _updateSubphaseStatus(
    BuildContext context, {
      required String projectId,
      required List<SelectedSubphase> selected,
      required String code,
      required String newStatus,
    }) async {
  final repo = ProjectRepository();
  final updated = selected
      .map((s) => s.code == code ? s.copyWith(status: newStatus).toMap() : s.toMap())
      .toList();
  await repo.update(projectId, {'selectedSubphases': updated});
}
