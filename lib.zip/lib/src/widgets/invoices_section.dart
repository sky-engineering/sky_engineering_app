// lib/src/widgets/invoices_section.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import '../data/models/invoice.dart';
import '../data/repositories/invoice_repository.dart';
import 'form_helpers.dart';

class InvoicesSection extends StatelessWidget {
  /// Project whose invoices are shown.
  final String projectId;

  /// Whether current user owns the project (enables editing).
  final bool isOwner;

  /// Used to prefill digits in the Add dialog.
  final String? projectNumberString;

  /// Optional section title. Defaults to 'Invoices' if not provided.
  final String? title;

  /// Optional filter for invoice type: 'Client' or 'Vendor'.
  /// If null, shows all invoices.
  final String? invoiceTypeFilter;

  const InvoicesSection({
    super.key,
    required this.projectId,
    required this.isOwner,
    this.projectNumberString,
    this.title,
    this.invoiceTypeFilter,
  });

  @override
  Widget build(BuildContext context) {
    final repo = InvoiceRepository();
    final currency = NumberFormat.simpleCurrency();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title ?? 'Invoices', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          StreamBuilder<List<Invoice>>(
            stream: repo.streamByProject(projectId),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Padding(
                  padding: EdgeInsets.all(12),
                  child: CircularProgressIndicator(),
                );
              }

              // Apply optional filter by invoice type
              var invoices = (snap.data ?? const <Invoice>[]);
              if (invoiceTypeFilter != null) {
                invoices = invoices
                    .where((inv) => inv.invoiceType == invoiceTypeFilter)
                    .toList();
              }

              if (invoices.isEmpty) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        invoiceTypeFilter == 'Vendor'
                            ? 'No vendor invoices yet'
                            : invoiceTypeFilter == 'Client'
                            ? 'No client invoices yet'
                            : 'No invoices yet',
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (isOwner)
                      Align(
                        alignment: Alignment.centerLeft,
                        child: FilledButton.icon(
                          onPressed: () => _showAddInvoiceDialog(
                            context,
                            projectId,
                            defaultProjectNumber: projectNumberString,
                            initialInvoiceType: invoiceTypeFilter ?? 'Client',
                          ),
                          icon: const Icon(Icons.add),
                          label: const Text('New Invoice'),
                        ),
                      ),
                  ],
                );
              }

              return Column(
                children: [
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: invoices.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final inv = invoices[i];

                      final subtitleBits = <String>[];
                      if (inv.invoiceDate != null) {
                        subtitleBits.add(fmtDate(inv.invoiceDate));
                      }
                      // BALANCE = amount - amountPaid (via getter)
                      subtitleBits.add('BALANCE ${currency.format(inv.balance)}');

                      return ListTile(
                        contentPadding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        // No leading avatar / icon
                        title: Text(
                          inv.invoiceNumber.isNotEmpty
                              ? 'Invoice ${inv.invoiceNumber}'
                              : 'Invoice ${inv.id.substring(0, 6)}',
                        ),
                        subtitle: Text(subtitleBits.join(' • ')),
                        trailing: Text(
                          currency.format(inv.invoiceAmount),
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        onTap: () => _showEditInvoiceDialog(
                          context,
                          inv,
                          canEdit: isOwner,
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  if (isOwner)
                    Align(
                      alignment: Alignment.centerLeft,
                      child: FilledButton.icon(
                        onPressed: () => _showAddInvoiceDialog(
                          context,
                          projectId,
                          defaultProjectNumber: projectNumberString,
                          initialInvoiceType: invoiceTypeFilter ?? 'Client',
                        ),
                        icon: const Icon(Icons.add),
                        label: const Text('New Invoice'),
                      ),
                    ),
                ],
              );
            },
          ),
        ]),
      ),
    );
  }
}

// ---------- dialog helpers (now use Amount Paid) ----------
Future<void> _showAddInvoiceDialog(
    BuildContext context,
    String projectId, {
      String? defaultProjectNumber,
      String initialInvoiceType = 'Client',
    }) async {
  final invoiceNumberCtl = TextEditingController();

  String initialProjNumText = '';
  if (defaultProjectNumber != null && defaultProjectNumber.trim().isNotEmpty) {
    final m = RegExp(r'\d+').firstMatch(defaultProjectNumber);
    if (m != null) initialProjNumText = m.group(0) ?? '';
  }
  final projectNumberCtl = TextEditingController(text: initialProjNumText);

  final invoiceAmountCtl = TextEditingController();
  final amountPaidCtl = TextEditingController(); // <-- changed
  final documentLinkCtl = TextEditingController();

  String invoiceType = (initialInvoiceType == 'Vendor') ? 'Vendor' : 'Client';
  DateTime? invoiceDate;
  DateTime? dueDate;
  DateTime? paidDate;

  final formKey = GlobalKey<FormState>();
  final repo = InvoiceRepository();
  final me = FirebaseAuth.instance.currentUser;

  if (me == null) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('You must be signed in.')));
    return;
  }

  Future<void> pickDate(String which) async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 5),
    );
    if (d != null) {
      switch (which) {
        case 'invoice':
          invoiceDate = d;
          break;
        case 'due':
          dueDate = d;
          break;
        case 'paid':
          paidDate = d;
          break;
      }
    }
  }

  await showDialog<void>(
    context: context,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('New Invoice'),
            content: Form(
              key: formKey,
              child: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      appTextField('Invoice Number', invoiceNumberCtl,
                          required: true, hint: 'e.g., 1220'),
                      const SizedBox(height: 10),
                      appTextField('Project Number', projectNumberCtl,
                          hint: 'optional (numbers only)'),
                      const SizedBox(height: 10),
                      appTextField('Invoice Amount', invoiceAmountCtl,
                          required: true,
                          hint: 'e.g., 17150.91',
                          keyboardType: TextInputType.number),
                      const SizedBox(height: 10),
                      appTextField('Amount Paid', amountPaidCtl,
                          hint: 'e.g., 2500.00', keyboardType: TextInputType.number),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: appDateField(
                              label: 'Invoice Date',
                              value: invoiceDate,
                              onPick: () async {
                                await pickDate('invoice');
                                setState(() {});
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: appDateField(
                              label: 'Due Date',
                              value: dueDate,
                              onPick: () async {
                                await pickDate('due');
                                setState(() {});
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      appDateField(
                        label: 'Paid Date',
                        value: paidDate,
                        onPick: () async {
                          await pickDate('paid');
                          setState(() {});
                        },
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: invoiceType,
                        items: const [
                          DropdownMenuItem(value: 'Client', child: Text('Client')),
                          DropdownMenuItem(value: 'Vendor', child: Text('Vendor')),
                        ],
                        onChanged: (v) => setState(() => invoiceType = v ?? 'Client'),
                        decoration: const InputDecoration(
                          labelText: 'Invoice Type',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 10),
                      appTextField('Document Link', documentLinkCtl,
                          hint: 'https://...'),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel')),
              FilledButton(
                onPressed: () async {
                  if (!(formKey.currentState?.validate() ?? false)) return;

                  final amt =
                      double.tryParse(invoiceAmountCtl.text.trim()) ?? 0.0;
                  final paid = amountPaidCtl.text.trim().isEmpty
                      ? 0.0
                      : (double.tryParse(amountPaidCtl.text.trim()) ?? 0.0);

                  int? projNum;
                  final pnText = projectNumberCtl.text.trim();
                  if (pnText.isNotEmpty) {
                    projNum = int.tryParse(pnText);
                  }

                  final me = FirebaseAuth.instance.currentUser;
                  final inv = Invoice(
                    id: '_',
                    projectId: projectId,
                    ownerUid: me?.uid,
                    invoiceNumber: invoiceNumberCtl.text.trim(),
                    projectNumber: projNum,
                    invoiceAmount: amt,
                    amountPaid: paid, // <-- canonical
                    invoiceDate: invoiceDate,
                    dueDate: dueDate,
                    paidDate: paidDate,
                    documentLink: documentLinkCtl.text.trim().isEmpty
                        ? null
                        : documentLinkCtl.text.trim(),
                    invoiceType: invoiceType,
                  );

                  try {
                    await repo.add(inv);
                    // ignore: use_build_context_synchronously
                    Navigator.pop(context);
                  } catch (e) {
                    // ignore: use_build_context_synchronously
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to create invoice: $e')),
                    );
                  }
                },
                child: const Text('Create'),
              ),
            ],
          );
        },
      );
    },
  );
}

Future<void> _showEditInvoiceDialog(BuildContext context, Invoice inv,
    {required bool canEdit}) async {
  final invoiceNumberCtl = TextEditingController(text: inv.invoiceNumber);
  final projectNumberCtl =
  TextEditingController(text: inv.projectNumber?.toString() ?? '');
  final invoiceAmountCtl =
  TextEditingController(text: inv.invoiceAmount.toStringAsFixed(2));
  final amountPaidCtl = TextEditingController(
      text: inv.amountPaid.toStringAsFixed(2)); // <-- changed
  final documentLinkCtl = TextEditingController(text: inv.documentLink ?? '');

  String invoiceType = inv.invoiceType;
  DateTime? invoiceDate = inv.invoiceDate;
  DateTime? dueDate = inv.dueDate;
  DateTime? paidDate = inv.paidDate;

  final formKey = GlobalKey<FormState>();
  final repo = InvoiceRepository();

  Future<void> pickDate(String which) async {
    final seed = (which == 'invoice')
        ? (invoiceDate ?? DateTime.now())
        : (which == 'due')
        ? (dueDate ?? DateTime.now())
        : (paidDate ?? DateTime.now());
    final d = await showDatePicker(
      context: context,
      initialDate: seed,
      firstDate: DateTime(seed.year - 5),
      lastDate: DateTime(seed.year + 5),
    );
    if (d != null) {
      switch (which) {
        case 'invoice':
          invoiceDate = d;
          break;
        case 'due':
          dueDate = d;
          break;
        case 'paid':
          paidDate = d;
          break;
      }
    }
  }

  void _viewOnlyTap() {
    if (!canEdit) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content:
            Text('View-only: only the project owner can modify invoices.')),
      );
    }
  }

  await showDialog<void>(
    context: context,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text('Invoice ${inv.invoiceNumber.isNotEmpty ? inv.invoiceNumber : inv.id.substring(0, 6)}'),
            content: Form(
              key: formKey,
              child: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      appTextField('Invoice Number', invoiceNumberCtl,
                          required: true),
                      const SizedBox(height: 10),
                      appTextField('Project Number', projectNumberCtl,
                          hint: 'numbers only'),
                      const SizedBox(height: 10),
                      appTextField('Invoice Amount', invoiceAmountCtl,
                          required: true, keyboardType: TextInputType.number),
                      const SizedBox(height: 10),
                      appTextField('Amount Paid', amountPaidCtl,
                          keyboardType: TextInputType.number), // <-- changed
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: appDateField(
                              label: 'Invoice Date',
                              value: invoiceDate,
                              onPick: () async {
                                if (!canEdit) return _viewOnlyTap();
                                await pickDate('invoice');
                                setState(() {});
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: appDateField(
                              label: 'Due Date',
                              value: dueDate,
                              onPick: () async {
                                if (!canEdit) return _viewOnlyTap();
                                await pickDate('due');
                                setState(() {});
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      appDateField(
                        label: 'Paid Date',
                        value: paidDate,
                        onPick: () async {
                          if (!canEdit) return _viewOnlyTap();
                          await pickDate('paid');
                          setState(() {});
                        },
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: invoiceType,
                        items: const [
                          DropdownMenuItem(value: 'Client', child: Text('Client')),
                          DropdownMenuItem(value: 'Vendor', child: Text('Vendor')),
                        ],
                        onChanged: canEdit
                            ? (v) =>
                            setState(() => invoiceType = v ?? invoiceType)
                            : (v) => _viewOnlyTap(),
                        decoration: const InputDecoration(
                          labelText: 'Invoice Type',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 10),
                      appTextField('Document Link', documentLinkCtl),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              if (canEdit)
                TextButton(
                  onPressed: () async {
                    final ok = await confirmDialog(
                        context, 'Delete this invoice?');
                    if (!ok) return;
                    try {
                      await repo.delete(inv.id);
                      // ignore: use_build_context_synchronously
                      Navigator.pop(context);
                    } catch (e) {
                      // ignore: use_build_context_synchronously
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Failed to delete: $e')));
                    }
                  },
                  child: const Text('Delete'),
                ),
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(canEdit ? 'Cancel' : 'Close')),
              if (canEdit)
                FilledButton(
                  onPressed: () async {
                    if (!(formKey.currentState?.validate() ?? false)) return;

                    final amt = double.tryParse(
                        invoiceAmountCtl.text.trim()) ??
                        inv.invoiceAmount;
                    final paid = amountPaidCtl.text.trim().isEmpty
                        ? inv.amountPaid
                        : (double.tryParse(amountPaidCtl.text.trim()) ??
                        inv.amountPaid);

                    int? projNum;
                    final pn = projectNumberCtl.text.trim();
                    if (pn.isNotEmpty) projNum = int.tryParse(pn);

                    try {
                      await repo.update(inv.id, {
                        'invoiceNumber': invoiceNumberCtl.text.trim(),
                        'projectNumber': projNum,
                        'invoiceAmount': amt,
                        'amountPaid': paid, // <-- canonical
                        'invoiceDate': invoiceDate != null
                            ? Timestamp.fromDate(invoiceDate!)
                            : null,
                        'dueDate': dueDate != null
                            ? Timestamp.fromDate(dueDate!)
                            : null,
                        'paidDate': paidDate != null
                            ? Timestamp.fromDate(paidDate!)
                            : null,
                        'documentLink': documentLinkCtl.text.trim().isNotEmpty
                            ? documentLinkCtl.text.trim()
                            : null,
                        'invoiceType': invoiceType,
                      });
                      // ignore: use_build_context_synchronously
                      Navigator.pop(context);
                    } catch (e) {
                      // ignore: use_build_context_synchronously
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Failed to save: $e')));
                    }
                  },
                  child: const Text('Save'),
                ),
            ],
          );
        },
      );
    },
  );
}
